module Blacklight
  VERSION = "3.0pre1"
end
