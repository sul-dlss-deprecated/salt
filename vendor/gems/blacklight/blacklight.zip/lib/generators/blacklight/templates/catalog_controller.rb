require 'blacklight/catalog'

class CatalogController < ApplicationController  

  include Blacklight::Catalog

end 
